// cart.js - Shared cart logic and prices for all menu pages

// Add all menu item prices here (combined from all pages)
const prices = {
    // Non Veg
    "Chicken Biryani": 120,
    "Egg Curry": 70,
    "Fish Fry": 90,
    "Chicken 65": 100,
    "Mutton Curry": 150,
    "Prawn Fry": 130,
    "Grilled Chicken": 180,
    "Chicken Lollipop": 90,
    // Starters
    "Paneer Tikka": 80,
    "Veg Manchurian": 70,
    "Gobi 65": 70,
    "Fish Fingers": 100,
    "Spring Rolls": 60,
    // Veg
    "Veg Biryani": 60,
    "Idly": 20,
    "Masala Dosa": 35,
    "Karam Dosa": 30,
    "Plain Dosa": 25,
    "Puri": 30,
    "Chapathi": 25,
    "Parota": 25,
    "Curd Rice": 30,
    "Meals": 70,
    // Snacks
    "Samosa": 15,
    "Puffs": 20,
    "Vada": 10,
    "Cutlet": 25,
    "Pakoda": 30,
    "Mirchi Bajji": 30,
    "Spring Roll": 20,
    // Ice Cream
    "Vanilla": 30,
    "Chocolate": 35,
    "Strawberry": 35,
    "Butterscotch": 35,
    "Mango": 35,
    "Pista": 40,
    "Kulfi": 40,
    "Choco Bar": 25,
    // Juice
    "Orange Juice": 25,
    "Apple Juice": 30,
    "Grape Juice": 30,
    "Watermelon Juice": 25,
    "Pineapple Juice": 30,
    "Mango Juice": 30,
    "Lemon Juice": 20,
    "Pomegranate Juice": 35,
    "Carrot Juice": 25,
    "Sprit": 20,
    "Maza": 25,
    "Badham": 35,
    "Pulpi Orange": 30
};

const cart = JSON.parse(localStorage.getItem('cart')) || {};

function addToCart(item, qtyInputId) {
    const qty = parseInt(document.getElementById(qtyInputId).value, 10) || 1;
    if (cart[item]) {
        cart[item] += qty;
        alert(item + " quantity increased to " + cart[item] + " in your cart!");
    } else {
        cart[item] = qty;
        alert(item + " (x" + qty + ") added to your cart!");
    }
    updateCartDisplay();
    saveCart();
}

function increaseInCart(item) {
    if (cart[item]) {
        cart[item] += 1;
        updateCartDisplay();
        saveCart();
    }
}

function decreaseFromCart(item) {
    if (cart[item]) {
        cart[item] -= 1;
        if (cart[item] <= 0) {
            delete cart[item];
        }
        updateCartDisplay();
        saveCart();
    }
}

function removeFromCart(item) {
    if (cart[item]) {
        delete cart[item];
        updateCartDisplay();
        saveCart();
    }
}

function orderNow(item) {
    // If not logged in, show user details page (user login form)
    if (localStorage.getItem('isLoggedIn') !== 'true') {
        alert('Please login to place your order.');
        window.location.href = 'user-details.html';
        return;
    }
    // Add the item to cart (if not already), then go to delivery details page
    if (!cart[item]) {
        cart[item] = 1;
        saveCart();
    }
    window.location.href = 'delivery-details.html';
}

function orderAll() {
    // If not logged in, show user details page (user login form)
    if (localStorage.getItem('isLoggedIn') !== 'true') {
        alert('Please login to place your order.');
        window.location.href = 'user-details.html';
        return;
    }
    if (Object.keys(cart).length === 0) {
        alert("Your cart is empty!");
        return;
    }
    // Go to delivery details page for address, payment, etc.
    window.location.href = 'delivery-details.html';
}

function updateCartDisplay() {
    const el = document.getElementById('cart-items');
    const orderBtn = document.getElementById('order-all-btn');
    let total = 0;
    const items = Object.keys(cart).map(item => {
        const price = prices[item] || 0;
        const itemTotal = price * cart[item];
        total += itemTotal;
        return `<span class="cart-item">
            <button class="remove-btn" title="Decrease" onclick="decreaseFromCart('${item}')">-</button>
            ${item} <span style="color:#1e40af;font-weight:600;">₹${price}</span>
            (x${cart[item]})
            <span style="color:#1e40af;">= ₹${itemTotal}</span>
            <button class="remove-btn" title="Increase" onclick="increaseInCart('${item}')">+</button>
            <button class="remove-btn" title="Remove" onclick="removeFromCart('${item}')">&times;</button>
        </span>`;
    });
    el.innerHTML = items.length
        ? items.join('') + `<div style="margin-top:8px;font-weight:600;">Total: ₹${total}</div>`
        : 'None';
    orderBtn.style.display = items.length ? 'block' : 'none';
}

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

document.addEventListener('DOMContentLoaded', updateCartDisplay);

window.prices = prices;
